#ifndef ITEST_H
#define ITEST_H

class ITest 
{
	public:
		virtual int getValue() = 0;
};
#endif