#ifndef ITEST_IMPL_H
#define ITEST_IMPL_H

#include "ITest.h"

class ITestImpl : public ITest
{	
	private:
	
	public:
		int getValue();

};
#endif