#include "TestHarness.h"

#include "sof/config/BundleConfiguration.h"

TEST( Stack, creation )
{
  
}