#ifndef BASE_TEST_CLASS_H
#define BASE_TEST_CLASS_H


class BaseTestClass
{
};


#endif