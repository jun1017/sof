#include "IServiceBImpl.h"

int IServiceBImpl::getValue()
{
	return 66;
}