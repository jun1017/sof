#include "IServiceAImpl.h"

int IServiceAImpl::getValue()
{
	return 13;
}