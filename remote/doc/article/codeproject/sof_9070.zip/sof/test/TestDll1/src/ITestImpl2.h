#ifndef ITEST_IMPL2_H
#define ITEST_IMPL2_H

#include "ITest.h"

class ITestImpl2 : public ITest
{	
	private:
	
	public:
		int getValue();

};
#endif